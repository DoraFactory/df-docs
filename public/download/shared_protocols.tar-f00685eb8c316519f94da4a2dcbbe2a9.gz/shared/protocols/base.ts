export interface BaseRequest {
    
}

export interface BaseResponse {
    
}

export interface BaseConf {
    
}

export interface BaseMessage {

}
