import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { CoinInfoType } from "../../../../postgres-entity/coin/coin_infos"

export interface ReqGetCoinInfo extends BaseRequest {
    coin_type_hash: string,
    token: string
}

export interface ResGetCoinInfo extends BaseResponse {
    coinInfo: CoinInfoType
}

export const conf: BaseConf = {
    
}
