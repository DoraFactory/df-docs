import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { CoinInfoType } from "../../../../postgres-entity/coin/coin_infos"

export interface ReqListCoinInfo extends BaseRequest {
    token: string
}

export interface ResListCoinInfo extends BaseResponse {
    coinInfos: CoinInfoType[],
    total: number
}

export const conf: BaseConf = {
    
}
