import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { CurrentCoinBalancesType } from '../../../../postgres-entity/coin/current_coin_balances';

export interface ReqListCurrentCoin extends BaseRequest {
    coin_type_hash: string,
    offset?: number,
    limit?: number,
    token: string
}

export interface ResListCurrentCoin extends BaseResponse {
    currentCoins: CurrentCoinBalancesType[],
    total: number
}

export const conf: BaseConf = {
    
}
