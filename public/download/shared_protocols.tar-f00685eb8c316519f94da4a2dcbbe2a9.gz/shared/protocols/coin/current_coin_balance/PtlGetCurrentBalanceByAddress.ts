import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { CurrentCoinBalancesType } from '../../../../postgres-entity/coin/current_coin_balances';

export interface ReqGetCurrentBalanceByAddress extends BaseRequest {
    owner_address: string,
    coin_type_hash: string,
    token: string
}

export interface ResGetCurrentBalanceByAddress extends BaseResponse {
    currentCoin: CurrentCoinBalancesType    
}

export const conf: BaseConf = {
    
}
