import { ServiceProto } from 'tsrpc-proto';
import { MsgListenEventsByAddress } from './blockchain/event/MsgListenEventsByAddress';
import { MsgListenLatestOneByAddress } from './blockchain/event/MsgListenLatestOneByAddress';
import { ReqListenEventsByAddress, ResListenEventsByAddress } from './blockchain/event/PtlListenEventsByAddress';
import { ReqListenLatestOneByAddress, ResListenLatestOneByAddress } from './blockchain/event/PtlListenLatestOneByAddress';
import { MsgListenResourcesByAddress } from './blockchain/move_resource/MsgListenResourcesByAddress';
import { ReqListenResourcesByAddress, ResListenResourcesByAddress } from './blockchain/move_resource/PtlListenResourcesByAddress';
import { ReqGetCoinInfo, ResGetCoinInfo } from './coin/coin_info/PtlGetCoinInfo';
import { ReqListCoinInfo, ResListCoinInfo } from './coin/coin_info/PtlListCoinInfo';
import { ReqGetCurrentBalanceByAddress, ResGetCurrentBalanceByAddress } from './coin/current_coin_balance/PtlGetCurrentBalanceByAddress';
import { ReqListCurrentBalanceByAddress, ResListCurrentBalanceByAddress } from './coin/current_coin_balance/PtlListCurrentBalanceByAddress';
import { ReqListCurrentCoin, ResListCurrentCoin } from './coin/current_coin_balance/PtlListCurrentCoin';
import { ReqGetCollectionDetailById, ResGetCollectionDetailById } from './token/collection_data/PtlGetCollectionDetailById';
import { ReqGetAnsByAddress, ResGetAnsByAddress } from './token/current_ans_lookup/PtlGetAnsByAddress';
import { ReqGetAnsByDomain, ResGetAnsByDomain } from './token/current_ans_lookup/PtlGetAnsByDomain';
import { ReqGetCurrentTokenById, ResGetCurrentTokenById } from './token/current_token_ownership/PtlGetCurrentTokenById';
import { ReqListCurrentToken, ResListCurrentToken } from './token/current_token_ownership/PtlListCurrentToken';
import { ReqListCurrentTokenByAddress, ResListCurrentTokenByAddress } from './token/current_token_ownership/PtlListCurrentTokenByAddress';
import { ReqGetTokenDetailById, ResGetTokenDetailById } from './token/token_data/PtlGetTokenDetailById';
import { ReqGetTokenById, ResGetTokenById } from './token/token_ownership/PtlGetTokenById';
import { ReqListTokenByAddress, ResListTokenByAddress } from './token/token_ownership/PtlListTokenByAddress';

export interface ServiceType {
    api: {
        "blockchain/event/ListenEventsByAddress": {
            req: ReqListenEventsByAddress,
            res: ResListenEventsByAddress
        },
        "blockchain/event/ListenLatestOneByAddress": {
            req: ReqListenLatestOneByAddress,
            res: ResListenLatestOneByAddress
        },
        "blockchain/move_resource/ListenResourcesByAddress": {
            req: ReqListenResourcesByAddress,
            res: ResListenResourcesByAddress
        },
        "coin/coin_info/GetCoinInfo": {
            req: ReqGetCoinInfo,
            res: ResGetCoinInfo
        },
        "coin/coin_info/ListCoinInfo": {
            req: ReqListCoinInfo,
            res: ResListCoinInfo
        },
        "coin/current_coin_balance/GetCurrentBalanceByAddress": {
            req: ReqGetCurrentBalanceByAddress,
            res: ResGetCurrentBalanceByAddress
        },
        "coin/current_coin_balance/ListCurrentBalanceByAddress": {
            req: ReqListCurrentBalanceByAddress,
            res: ResListCurrentBalanceByAddress
        },
        "coin/current_coin_balance/ListCurrentCoin": {
            req: ReqListCurrentCoin,
            res: ResListCurrentCoin
        },
        "token/collection_data/GetCollectionDetailById": {
            req: ReqGetCollectionDetailById,
            res: ResGetCollectionDetailById
        },
        "token/current_ans_lookup/GetAnsByAddress": {
            req: ReqGetAnsByAddress,
            res: ResGetAnsByAddress
        },
        "token/current_ans_lookup/GetAnsByDomain": {
            req: ReqGetAnsByDomain,
            res: ResGetAnsByDomain
        },
        "token/current_token_ownership/GetCurrentTokenById": {
            req: ReqGetCurrentTokenById,
            res: ResGetCurrentTokenById
        },
        "token/current_token_ownership/ListCurrentToken": {
            req: ReqListCurrentToken,
            res: ResListCurrentToken
        },
        "token/current_token_ownership/ListCurrentTokenByAddress": {
            req: ReqListCurrentTokenByAddress,
            res: ResListCurrentTokenByAddress
        },
        "token/token_data/GetTokenDetailById": {
            req: ReqGetTokenDetailById,
            res: ResGetTokenDetailById
        },
        "token/token_ownership/GetTokenById": {
            req: ReqGetTokenById,
            res: ResGetTokenById
        },
        "token/token_ownership/ListTokenByAddress": {
            req: ReqListTokenByAddress,
            res: ResListTokenByAddress
        }
    },
    msg: {
        "blockchain/event/ListenEventsByAddress": MsgListenEventsByAddress,
        "blockchain/event/ListenLatestOneByAddress": MsgListenLatestOneByAddress,
        "blockchain/move_resource/ListenResourcesByAddress": MsgListenResourcesByAddress
    }
}

export const serviceProto: ServiceProto<ServiceType> = {
    "version": 38,
    "services": [
        {
            "id": 59,
            "name": "blockchain/event/ListenEventsByAddress",
            "type": "msg"
        },
        {
            "id": 41,
            "name": "blockchain/event/ListenLatestOneByAddress",
            "type": "msg"
        },
        {
            "id": 60,
            "name": "blockchain/event/ListenEventsByAddress",
            "type": "api",
            "conf": {}
        },
        {
            "id": 43,
            "name": "blockchain/event/ListenLatestOneByAddress",
            "type": "api",
            "conf": {}
        },
        {
            "id": 61,
            "name": "blockchain/move_resource/ListenResourcesByAddress",
            "type": "msg"
        },
        {
            "id": 62,
            "name": "blockchain/move_resource/ListenResourcesByAddress",
            "type": "api",
            "conf": {}
        },
        {
            "id": 44,
            "name": "coin/coin_info/GetCoinInfo",
            "type": "api",
            "conf": {}
        },
        {
            "id": 45,
            "name": "coin/coin_info/ListCoinInfo",
            "type": "api",
            "conf": {}
        },
        {
            "id": 63,
            "name": "coin/current_coin_balance/GetCurrentBalanceByAddress",
            "type": "api",
            "conf": {}
        },
        {
            "id": 46,
            "name": "coin/current_coin_balance/ListCurrentBalanceByAddress",
            "type": "api",
            "conf": {}
        },
        {
            "id": 47,
            "name": "coin/current_coin_balance/ListCurrentCoin",
            "type": "api",
            "conf": {}
        },
        {
            "id": 48,
            "name": "token/collection_data/GetCollectionDetailById",
            "type": "api",
            "conf": {}
        },
        {
            "id": 57,
            "name": "token/current_ans_lookup/GetAnsByAddress",
            "type": "api",
            "conf": {}
        },
        {
            "id": 58,
            "name": "token/current_ans_lookup/GetAnsByDomain",
            "type": "api",
            "conf": {}
        },
        {
            "id": 49,
            "name": "token/current_token_ownership/GetCurrentTokenById",
            "type": "api",
            "conf": {}
        },
        {
            "id": 50,
            "name": "token/current_token_ownership/ListCurrentToken",
            "type": "api",
            "conf": {}
        },
        {
            "id": 51,
            "name": "token/current_token_ownership/ListCurrentTokenByAddress",
            "type": "api",
            "conf": {}
        },
        {
            "id": 52,
            "name": "token/token_data/GetTokenDetailById",
            "type": "api",
            "conf": {}
        },
        {
            "id": 53,
            "name": "token/token_ownership/GetTokenById",
            "type": "api",
            "conf": {}
        },
        {
            "id": 55,
            "name": "token/token_ownership/ListTokenByAddress",
            "type": "api",
            "conf": {}
        }
    ],
    "types": {
        "blockchain/event/MsgListenEventsByAddress/MsgListenEventsByAddress": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "events",
                    "type": {
                        "type": "Array",
                        "elementType": {
                            "type": "Reference",
                            "target": "../../postgres-entity/blockchain/events/EventType"
                        }
                    }
                },
                {
                    "id": 1,
                    "name": "total",
                    "type": {
                        "type": "Number"
                    }
                }
            ]
        },
        "../../postgres-entity/blockchain/events/EventType": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "sequence_number",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "creation_number",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "account_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 3,
                    "name": "transaction_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 4,
                    "name": "transaction_block_height",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 5,
                    "name": "type",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 6,
                    "name": "data",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 7,
                    "name": "inserted_at",
                    "type": {
                        "type": "Date"
                    }
                }
            ]
        },
        "blockchain/event/MsgListenLatestOneByAddress/MsgListenLatestOneByAddress": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "sequence_number",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "creation_number",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "account_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 3,
                    "name": "transaction_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 4,
                    "name": "transaction_block_height",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 5,
                    "name": "type",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 6,
                    "name": "data",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 7,
                    "name": "inserted_at",
                    "type": {
                        "type": "Date"
                    }
                }
            ]
        },
        "blockchain/event/PtlListenEventsByAddress/ReqListenEventsByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "account_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "startVersion",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 2,
                    "name": "endVersion",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 3,
                    "name": "offset",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 4,
                    "name": "limit",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 5,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "base/BaseRequest": {
            "type": "Interface"
        },
        "blockchain/event/PtlListenEventsByAddress/ResListenEventsByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "events",
                    "type": {
                        "type": "Array",
                        "elementType": {
                            "type": "Reference",
                            "target": "../../postgres-entity/blockchain/events/EventType"
                        }
                    }
                },
                {
                    "id": 1,
                    "name": "total",
                    "type": {
                        "type": "Number"
                    }
                }
            ]
        },
        "base/BaseResponse": {
            "type": "Interface"
        },
        "blockchain/event/PtlListenLatestOneByAddress/ReqListenLatestOneByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "account_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "blockchain/event/PtlListenLatestOneByAddress/ResListenLatestOneByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "sequence_number",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "creation_number",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "account_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 3,
                    "name": "transaction_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 4,
                    "name": "transaction_block_height",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 5,
                    "name": "type",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 6,
                    "name": "data",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 7,
                    "name": "inserted_at",
                    "type": {
                        "type": "Date"
                    }
                }
            ]
        },
        "blockchain/move_resource/MsgListenResourcesByAddress/MsgListenResourcesByAddress": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "resources",
                    "type": {
                        "type": "Array",
                        "elementType": {
                            "type": "Reference",
                            "target": "../../postgres-entity/blockchain/move_resources/MoveResourceType"
                        }
                    }
                },
                {
                    "id": 1,
                    "name": "total",
                    "type": {
                        "type": "Number"
                    }
                }
            ]
        },
        "../../postgres-entity/blockchain/move_resources/MoveResourceType": {
            "type": "Interface",
            "properties": [
                {
                    "id": 3,
                    "name": "transaction_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 8,
                    "name": "write_set_change_index",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 4,
                    "name": "transaction_block_height",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 9,
                    "name": "name",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 10,
                    "name": "address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 5,
                    "name": "type",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 11,
                    "name": "module",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 12,
                    "name": "generic_type_params",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 6,
                    "name": "data",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 7,
                    "name": "inserted_at",
                    "type": {
                        "type": "Date"
                    }
                }
            ]
        },
        "blockchain/move_resource/PtlListenResourcesByAddress/ReqListenResourcesByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "module",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 2,
                    "name": "name",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 3,
                    "name": "startVersion",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 4,
                    "name": "endVersion",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 5,
                    "name": "offset",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 6,
                    "name": "limit",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 7,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "blockchain/move_resource/PtlListenResourcesByAddress/ResListenResourcesByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "resources",
                    "type": {
                        "type": "Array",
                        "elementType": {
                            "type": "Reference",
                            "target": "../../postgres-entity/blockchain/move_resources/MoveResourceType"
                        }
                    }
                },
                {
                    "id": 1,
                    "name": "total",
                    "type": {
                        "type": "Number"
                    }
                }
            ]
        },
        "coin/coin_info/PtlGetCoinInfo/ReqGetCoinInfo": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "coin_type_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "coin/coin_info/PtlGetCoinInfo/ResGetCoinInfo": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 1,
                    "name": "coinInfo",
                    "type": {
                        "type": "Reference",
                        "target": "../../postgres-entity/coin/coin_infos/CoinInfoType"
                    }
                }
            ]
        },
        "../../postgres-entity/coin/coin_infos/CoinInfoType": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "coin_type_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "coin_type",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "transaction_version_created",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 3,
                    "name": "creator_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 4,
                    "name": "name",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 5,
                    "name": "symbol",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 6,
                    "name": "decimals",
                    "type": {
                        "type": "Number"
                    }
                },
                {
                    "id": 7,
                    "name": "transaction_created_timestamp",
                    "type": {
                        "type": "Date"
                    }
                },
                {
                    "id": 8,
                    "name": "inserted_at",
                    "type": {
                        "type": "Date"
                    }
                },
                {
                    "id": 9,
                    "name": "supply_aggregator_table_handle",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 10,
                    "name": "supply_aggregator_table_key",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "coin/coin_info/PtlListCoinInfo/ReqListCoinInfo": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "coin/coin_info/PtlListCoinInfo/ResListCoinInfo": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "coinInfos",
                    "type": {
                        "type": "Array",
                        "elementType": {
                            "type": "Reference",
                            "target": "../../postgres-entity/coin/coin_infos/CoinInfoType"
                        }
                    }
                },
                {
                    "id": 1,
                    "name": "total",
                    "type": {
                        "type": "Number"
                    }
                }
            ]
        },
        "coin/current_coin_balance/PtlGetCurrentBalanceByAddress/ReqGetCurrentBalanceByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "owner_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "coin_type_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "coin/current_coin_balance/PtlGetCurrentBalanceByAddress/ResGetCurrentBalanceByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "currentCoin",
                    "type": {
                        "type": "Reference",
                        "target": "../../postgres-entity/coin/current_coin_balances/CurrentCoinBalancesType"
                    }
                }
            ]
        },
        "../../postgres-entity/coin/current_coin_balances/CurrentCoinBalancesType": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "owner_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "coin_type_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "coin_type",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 3,
                    "name": "amount",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 4,
                    "name": "last_transaction_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 5,
                    "name": "last_transaction_timestamp",
                    "type": {
                        "type": "Date"
                    }
                },
                {
                    "id": 6,
                    "name": "inserted_at",
                    "type": {
                        "type": "Date"
                    }
                }
            ]
        },
        "coin/current_coin_balance/PtlListCurrentBalanceByAddress/ReqListCurrentBalanceByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "owner_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "offset",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 3,
                    "name": "limit",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 1,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "coin/current_coin_balance/PtlListCurrentBalanceByAddress/ResListCurrentBalanceByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "currentCoins",
                    "type": {
                        "type": "Array",
                        "elementType": {
                            "type": "Reference",
                            "target": "../../postgres-entity/coin/current_coin_balances/CurrentCoinBalancesType"
                        }
                    }
                },
                {
                    "id": 1,
                    "name": "total",
                    "type": {
                        "type": "Number"
                    }
                }
            ]
        },
        "coin/current_coin_balance/PtlListCurrentCoin/ReqListCurrentCoin": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "coin_type_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "offset",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 3,
                    "name": "limit",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 4,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "coin/current_coin_balance/PtlListCurrentCoin/ResListCurrentCoin": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "currentCoins",
                    "type": {
                        "type": "Array",
                        "elementType": {
                            "type": "Reference",
                            "target": "../../postgres-entity/coin/current_coin_balances/CurrentCoinBalancesType"
                        }
                    }
                },
                {
                    "id": 1,
                    "name": "total",
                    "type": {
                        "type": "Number"
                    }
                }
            ]
        },
        "token/collection_data/PtlGetCollectionDetailById/ReqGetCollectionDetailById": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "collection_data_id_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "transaction_version",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 2,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "token/collection_data/PtlGetCollectionDetailById/ResGetCollectionDetailById": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "collectionData",
                    "type": {
                        "type": "Reference",
                        "target": "../../postgres-entity/token/collection_datas/CollectionDataType"
                    }
                }
            ]
        },
        "../../postgres-entity/token/collection_datas/CollectionDataType": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "collection_data_id_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "transaction_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "creator_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 3,
                    "name": "collection_name",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 4,
                    "name": "description",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 5,
                    "name": "metadata_uri",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 6,
                    "name": "supply",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 7,
                    "name": "maximum",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 8,
                    "name": "maximum_mutable",
                    "type": {
                        "type": "Boolean"
                    }
                },
                {
                    "id": 9,
                    "name": "uri_mutable",
                    "type": {
                        "type": "Boolean"
                    }
                },
                {
                    "id": 10,
                    "name": "description_mutable",
                    "type": {
                        "type": "Boolean"
                    }
                },
                {
                    "id": 11,
                    "name": "inserted_at",
                    "type": {
                        "type": "Date"
                    }
                },
                {
                    "id": 12,
                    "name": "table_handle",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 13,
                    "name": "transaction_timestamp",
                    "type": {
                        "type": "Date"
                    }
                }
            ]
        },
        "token/current_ans_lookup/PtlGetAnsByAddress/ReqGetAnsByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "offset",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 2,
                    "name": "limit",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 3,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "token/current_ans_lookup/PtlGetAnsByAddress/ResGetAnsByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "currentAns",
                    "type": {
                        "type": "Array",
                        "elementType": {
                            "type": "Reference",
                            "target": "../../postgres-entity/token/current_ans_lookup/CurrentAnsLookupType"
                        }
                    }
                },
                {
                    "id": 1,
                    "name": "total",
                    "type": {
                        "type": "Number"
                    }
                }
            ]
        },
        "../../postgres-entity/token/current_ans_lookup/CurrentAnsLookupType": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "domain",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "subdomain",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "registered_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 3,
                    "name": "expiration_timestamp",
                    "type": {
                        "type": "Date"
                    }
                },
                {
                    "id": 4,
                    "name": "last_transaction_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 5,
                    "name": "inserted_at",
                    "type": {
                        "type": "Date"
                    }
                }
            ]
        },
        "token/current_ans_lookup/PtlGetAnsByDomain/ReqGetAnsByDomain": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "domain",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 4,
                    "name": "subdomain",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 1,
                    "name": "offset",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 2,
                    "name": "limit",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 3,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "token/current_ans_lookup/PtlGetAnsByDomain/ResGetAnsByDomain": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "currentAns",
                    "type": {
                        "type": "Array",
                        "elementType": {
                            "type": "Reference",
                            "target": "../../postgres-entity/token/current_ans_lookup/CurrentAnsLookupType"
                        }
                    }
                },
                {
                    "id": 1,
                    "name": "total",
                    "type": {
                        "type": "Number"
                    }
                }
            ]
        },
        "token/current_token_ownership/PtlGetCurrentTokenById/ReqGetCurrentTokenById": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 1,
                    "name": "token_data_id_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 3,
                    "name": "last_transaction_version",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 2,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "token/current_token_ownership/PtlGetCurrentTokenById/ResGetCurrentTokenById": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "currentToken",
                    "type": {
                        "type": "Reference",
                        "target": "../../postgres-entity/token/current_token_ownerships/CurrentTokenOwnershipType"
                    }
                }
            ]
        },
        "../../postgres-entity/token/current_token_ownerships/CurrentTokenOwnershipType": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "token_data_id_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "property_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "owner_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 3,
                    "name": "creator_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 4,
                    "name": "collection_name",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 5,
                    "name": "name",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 6,
                    "name": "amount",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 7,
                    "name": "token_properties",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 8,
                    "name": "last_transaction_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 9,
                    "name": "inserted_at",
                    "type": {
                        "type": "Date"
                    }
                },
                {
                    "id": 10,
                    "name": "collection_data_id_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 11,
                    "name": "table_type",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 12,
                    "name": "last_transaction_timestamp",
                    "type": {
                        "type": "Date"
                    }
                }
            ]
        },
        "token/current_token_ownership/PtlListCurrentToken/ReqListCurrentToken": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "creator_address",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 1,
                    "name": "collections_name",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 2,
                    "name": "offset",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 3,
                    "name": "limit",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 4,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "token/current_token_ownership/PtlListCurrentToken/ResListCurrentToken": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "currentTokens",
                    "type": {
                        "type": "Array",
                        "elementType": {
                            "type": "Reference",
                            "target": "../../postgres-entity/token/current_token_ownerships/CurrentTokenOwnershipType"
                        }
                    }
                },
                {
                    "id": 1,
                    "name": "total",
                    "type": {
                        "type": "Number"
                    }
                }
            ]
        },
        "token/current_token_ownership/PtlListCurrentTokenByAddress/ReqListCurrentTokenByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "owner_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "offset",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 2,
                    "name": "limit",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 3,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "token/current_token_ownership/PtlListCurrentTokenByAddress/ResListCurrentTokenByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "currentTokens",
                    "type": {
                        "type": "Array",
                        "elementType": {
                            "type": "Reference",
                            "target": "../../postgres-entity/token/current_token_ownerships/CurrentTokenOwnershipType"
                        }
                    }
                },
                {
                    "id": 1,
                    "name": "total",
                    "type": {
                        "type": "Number"
                    }
                }
            ]
        },
        "token/token_data/PtlGetTokenDetailById/ReqGetTokenDetailById": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "token_data_id_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "transaction_version",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 2,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "token/token_data/PtlGetTokenDetailById/ResGetTokenDetailById": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "tokenData",
                    "type": {
                        "type": "Reference",
                        "target": "../../postgres-entity/token/token_datas/TokenDataType"
                    }
                }
            ]
        },
        "../../postgres-entity/token/token_datas/TokenDataType": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "token_data_id_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "transaction_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "creator_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 3,
                    "name": "collection_name",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 4,
                    "name": "name",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 5,
                    "name": "maximum",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 6,
                    "name": "supply",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 7,
                    "name": "largest_property_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 8,
                    "name": "metadata_uri",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 9,
                    "name": "payee_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 10,
                    "name": "royalty_points_numerator",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 11,
                    "name": "royalty_points_denominator",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 12,
                    "name": "maximum_mutable",
                    "type": {
                        "type": "Boolean"
                    }
                },
                {
                    "id": 13,
                    "name": "uri_mutable",
                    "type": {
                        "type": "Boolean"
                    }
                },
                {
                    "id": 14,
                    "name": "description_mutable",
                    "type": {
                        "type": "Boolean"
                    }
                },
                {
                    "id": 15,
                    "name": "properties_mutable",
                    "type": {
                        "type": "Boolean"
                    }
                },
                {
                    "id": 16,
                    "name": "royalty_mutable",
                    "type": {
                        "type": "Boolean"
                    }
                },
                {
                    "id": 17,
                    "name": "default_properties",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 18,
                    "name": "inserted_at",
                    "type": {
                        "type": "Date"
                    }
                },
                {
                    "id": 19,
                    "name": "collection_data_id_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 20,
                    "name": "transaction_timestamp",
                    "type": {
                        "type": "Date"
                    }
                },
                {
                    "id": 21,
                    "name": "description",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "token/token_ownership/PtlGetTokenById/ReqGetTokenById": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 1,
                    "name": "token_data_id_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 3,
                    "name": "property_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 4,
                    "name": "table_handle",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 5,
                    "name": "transaction_version",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 2,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "token/token_ownership/PtlGetTokenById/ResGetTokenById": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "token",
                    "type": {
                        "type": "Reference",
                        "target": "../../postgres-entity/token/token_ownerships/TokenOwnershipType"
                    }
                }
            ]
        },
        "../../postgres-entity/token/token_ownerships/TokenOwnershipType": {
            "type": "Interface",
            "properties": [
                {
                    "id": 0,
                    "name": "token_data_id_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 1,
                    "name": "property_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 2,
                    "name": "transaction_version",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 3,
                    "name": "table_handle",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 4,
                    "name": "collection_name",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 5,
                    "name": "name",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 6,
                    "name": "owner_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 7,
                    "name": "amount",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 8,
                    "name": "table_type",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 9,
                    "name": "inserted_at",
                    "type": {
                        "type": "Date"
                    }
                },
                {
                    "id": 10,
                    "name": "collection_data_id_hash",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 11,
                    "name": "transaction_timestamp",
                    "type": {
                        "type": "Date"
                    }
                }
            ]
        },
        "token/token_ownership/PtlListTokenByAddress/ReqListTokenByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseRequest"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "owner_address",
                    "type": {
                        "type": "String"
                    }
                },
                {
                    "id": 4,
                    "name": "transaction_version",
                    "type": {
                        "type": "String"
                    },
                    "optional": true
                },
                {
                    "id": 1,
                    "name": "offset",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 2,
                    "name": "limit",
                    "type": {
                        "type": "Number"
                    },
                    "optional": true
                },
                {
                    "id": 3,
                    "name": "token",
                    "type": {
                        "type": "String"
                    }
                }
            ]
        },
        "token/token_ownership/PtlListTokenByAddress/ResListTokenByAddress": {
            "type": "Interface",
            "extends": [
                {
                    "id": 0,
                    "type": {
                        "type": "Reference",
                        "target": "base/BaseResponse"
                    }
                }
            ],
            "properties": [
                {
                    "id": 0,
                    "name": "tokens",
                    "type": {
                        "type": "Array",
                        "elementType": {
                            "type": "Reference",
                            "target": "../../postgres-entity/token/token_ownerships/TokenOwnershipType"
                        }
                    }
                },
                {
                    "id": 1,
                    "name": "total",
                    "type": {
                        "type": "Number"
                    }
                }
            ]
        }
    }
};