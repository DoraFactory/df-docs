import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { CurrentAnsLookupType } from '../../../../postgres-entity/token/current_ans_lookup';

export interface ReqGetAnsByDomain extends BaseRequest {
    domain: string,
    subdomain?: string,
    offset?: number,
    limit?: number,
    token: string
}

export interface ResGetAnsByDomain extends BaseResponse {
    currentAns: CurrentAnsLookupType[],
    total: number
}

export const conf: BaseConf = {
    
}
