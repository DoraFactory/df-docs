import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { CurrentAnsLookupType } from '../../../../postgres-entity/token/current_ans_lookup';

export interface ReqGetAnsByAddress extends BaseRequest {
    address: string,
    offset?: number,
    limit?: number,
    token: string
}

export interface ResGetAnsByAddress extends BaseResponse {
    currentAns: CurrentAnsLookupType[],
    total: number
}

export const conf: BaseConf = {
    
}
