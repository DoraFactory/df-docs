import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { CollectionDataType } from '../../../../postgres-entity/token/collection_datas';

export interface ReqGetCollectionDetailById extends BaseRequest {
    collection_data_id_hash: string, 
    transaction_version?: string,
    token: string
}

export interface ResGetCollectionDetailById extends BaseResponse {
    collectionData: CollectionDataType
}

export const conf: BaseConf = {
    
}
