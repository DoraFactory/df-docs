import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { CurrentTokenOwnershipType } from '../../../../postgres-entity/token/current_token_ownerships';

export interface ReqListCurrentToken extends BaseRequest {
    creator_address?: string, 
    collections_name?: string,
    offset?: number, 
    limit?: number,
    token: string
}

export interface ResListCurrentToken extends BaseResponse {
    currentTokens: CurrentTokenOwnershipType[],
    total: number
}

export const conf: BaseConf = {
    
}
