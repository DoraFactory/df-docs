import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { CurrentTokenOwnershipType } from '../../../../postgres-entity/token/current_token_ownerships';

export interface ReqListCurrentTokenByAddress extends BaseRequest {
    owner_address: string,
    offset?: number,
    limit?: number,
    token: string
}

export interface ResListCurrentTokenByAddress extends BaseResponse {
    currentTokens: CurrentTokenOwnershipType[],
    total: number
}

export const conf: BaseConf = {
    
}
