import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { CurrentTokenOwnershipType } from '../../../../postgres-entity/token/current_token_ownerships';

export interface ReqGetCurrentTokenById extends BaseRequest {
    token_data_id_hash: string,
    last_transaction_version?: string, 
    token: string
}

export interface ResGetCurrentTokenById extends BaseResponse {
    currentToken: CurrentTokenOwnershipType
}

export const conf: BaseConf = {
    
}
