import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { TokenDataType } from '../../../../postgres-entity/token/token_datas';

export interface ReqGetTokenDetailById extends BaseRequest {
    token_data_id_hash: string,
    transaction_version?: string,
    token: string
}

export interface ResGetTokenDetailById extends BaseResponse {
    tokenData: TokenDataType
}

export const conf: BaseConf = {
    
}
