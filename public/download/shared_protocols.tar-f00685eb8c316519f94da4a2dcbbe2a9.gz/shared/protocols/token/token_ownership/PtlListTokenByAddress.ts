import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { TokenOwnershipType } from '../../../../postgres-entity/token/token_ownerships';

export interface ReqListTokenByAddress extends BaseRequest {
    owner_address: string,
    transaction_version?: string,
    offset?: number,
    limit?: number,
    token: string
}

export interface ResListTokenByAddress extends BaseResponse {
    tokens: TokenOwnershipType[],
    total: number   
}

export const conf: BaseConf = {
    
}
