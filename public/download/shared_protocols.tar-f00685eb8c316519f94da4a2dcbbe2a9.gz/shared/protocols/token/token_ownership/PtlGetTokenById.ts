import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { TokenOwnershipType } from '../../../../postgres-entity/token/token_ownerships';

export interface ReqGetTokenById extends BaseRequest {
    token_data_id_hash: string;
    property_version: string;
    table_handle: string;
    transaction_version?: string;
    token: string
}

export interface ResGetTokenById extends BaseResponse {
    token: TokenOwnershipType
}

export const conf: BaseConf = {
    
}
