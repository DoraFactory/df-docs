import { EventType } from "../../../../postgres-entity/blockchain/events"

export interface MsgListenEventsByAddress {
    events: EventType[],
    total: number
}
