export interface MsgListenLatestOneByAddress {
    sequence_number: string,
    creation_number: string,
    account_address: string,
    transaction_version: string,
    transaction_block_height: string,
    type: string,
    data: string,
    inserted_at: Date,
}
