import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { EventType } from "../../../../postgres-entity/blockchain/events"

export interface ReqListenEventsByAddress extends BaseRequest {
    account_address: string,
    startVersion?: string,
    endVersion?: string,
    offset?: number,
    limit?: number,
    token: string
}

export interface ResListenEventsByAddress extends BaseResponse {
    events: EventType[],
    total: number
}

export const conf: BaseConf = {
    
}
