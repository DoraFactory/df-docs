import { MoveResourceType } from "../../../../postgres-entity/blockchain/move_resources"

export interface MsgListenResourcesByAddress {
    resources: MoveResourceType[],
    total: number
}
