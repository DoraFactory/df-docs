import { BaseRequest, BaseResponse, BaseConf } from "../../base";
import { MoveResourceType } from "../../../../postgres-entity/blockchain/move_resources"

export interface ReqListenResourcesByAddress extends BaseRequest {
    address: string,
    module?: string,
    name?: string,
    startVersion?: string,
    endVersion?: string,
    offset?: number,
    limit?: number,
    token: string
}

export interface ResListenResourcesByAddress extends BaseResponse {
    resources: MoveResourceType[],
    total: number
}

export const conf: BaseConf = {
    
}
